#ifndef _ANTENNA_H
#define _ANTENNA_H

void antenna_init(void);
void antenna_select(const uint8_t _ant);

#endif