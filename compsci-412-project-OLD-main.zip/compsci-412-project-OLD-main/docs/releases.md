# Releases

See all releases at [https://github.com/cyberman54/ESP32-Paxcounter/releases](https://github.com/cyberman54/ESP32-Paxcounter/releases).